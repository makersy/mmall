// 通用模块

// 引入通用css样式
require('./layout.css');
// 引入font-awesome
require('node_modules/font-awesome/css/font-awesome.min.css');
// 引用footer样式
require('./footer/index.css');